#ifndef THREADS_KMONITOR_H
#define THREADS_KMONITOR_H

/* Runs the interactive kernel. */
void interactive_kernel(void);

#endif /* threads/kmonitor.h */
